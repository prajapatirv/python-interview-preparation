# Interview Prep (Java Lead edition) - reusable for any stack

A data-driven interview study kit: **topics are Markdown, the app is generated**.
Same repo can later hold Python topics (`topics/py-*.md`) next to Java ones.

## Quick start
```bash
python3 build_site.py --title "Java Lead Interview Prep"   # writes index.html + QUESTION_INDEX.md
# open index.html in a browser (works offline)
```

## What is inside
| File | Purpose |
|---|---|
| `APP_BUILD_PROMPT.md` | Prompt A: build the app. Prompt B: generate a new topic. Prompt C: tailor to a resume |
| `topics/*.md` | 21 topics, 15-25 Q&A each, ordered basic -> intermediate -> advanced -> design |
| `topics/_TEMPLATE.md` | Format + authoring rules for new topics |
| `build_site.py` | Parser + validator + static site generator (Python stdlib only) |
| `QUESTION_INDEX.md` | Auto-generated index (counts per topic/level) |

## Topic map
1-4 Java core, modern Java (8 -> 25), concurrency, JVM/GC | 5-6 Spring Boot, JPA/security |
7-8 REST, microservices | 9 Kafka/RabbitMQ | 10-11 SQL/Oracle, NoSQL | 12-14 Azure(+AWS), Kubernetes/OpenShift, observability (Splunk/Grafana/Prometheus) |
15-17 system design, production RCA, patterns/architecture | 18 testing/CI-CD | 19 resume stack deep dive |
20 leadership/behavioral | 21 trending Lead-level topics (2026)

## How to study (7 days)
1. Day 1-2: topics 21, 05, 08, 09 (highest probability for Lead profiles).
2. Day 3: topics 01-03 (core, modern Java, concurrency).
3. Day 4: topics 15, 16 (design + RCA - prepare two whiteboard designs and two incident stories).
4. Day 5: gap topics 11-14 (NoSQL, Azure, K8s/OpenShift, observability) - learn the vocabulary and the honest-answer questions.
5. Day 6: topics 19, 20 (resume + behavioral stories).
6. Day 7: "Mock: random 10" with answers hidden; answer out loud; tick questions you can answer confidently.

## Add a topic
Copy `topics/_TEMPLATE.md` to `topics/22-your-topic.md`, keep the heading format
`### Q<n> [basic|intermediate|advanced|design] Question`, run `python3 build_site.py`.

## Deploy (optional)
Commit `index.html` and enable GitHub Pages on the repo (branch `main`, root).
